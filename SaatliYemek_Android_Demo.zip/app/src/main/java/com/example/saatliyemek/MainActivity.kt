package com.example.saatliyemek

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Food(val name: String, val restaurant: String, val price: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SaatliYemekApp() }
    }
}

@Composable
fun SaatliYemekApp() {
    val foods = listOf(
        Food("Lahmacun", "Saatlı Kabab", 3.0),
        Food("Dönər", "Dost Dönər", 4.0),
        Food("Pizza", "Pizza House", 9.0),
        Food("Toyuq kababı", "Saatlı Kabab", 7.0)
    )
    var cart by remember { mutableStateOf(listOf<Food>()) }
    var showCart by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("🍔 Saatlı Yemək") },
                    actions = {
                        TextButton(onClick = { showCart = true }) {
                            Text("Səbət (${cart.size})")
                        }
                    }
                )
            }
        ) { padding ->
            if (showCart) {
                Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("Sifariş səbəti", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp))
                    if (cart.isEmpty()) Text("Səbət boşdur.")
                    else {
                        cart.forEach { Text("${it.name} — ${it.price} AZN") }
                        Spacer(Modifier.height(12.dp))
                        Text("Cəmi: %.2f AZN".format(cart.sumOf { it.price }))
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { showCart = false }) { Text("Sifarişə davam et") }
                    }
                    TextButton(onClick = { showCart = false }) { Text("Geri") }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.padding(padding).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("Saatlıda yeməyini seç və sifariş et.",
                            style = MaterialTheme.typography.titleMedium)
                    }
                    items(foods) { food ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(food.name, style = MaterialTheme.typography.titleLarge)
                                Text(food.restaurant)
                                Text("%.2f AZN".format(food.price))
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { cart = cart + food }) {
                                    Text("Səbətə əlavə et")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
